Kiosk Demo app
--------------
->The starting form(StartPage form) gives you 2 options, either to check the leaderboard or rate the demos.
->If Rate the demos option is selected you will be navigated to a form(FormUser form) where the user should register by typing their name.
       ->On registering, you will be navigated to a form(DemoList form) where the list of demos with name and description will be displayed as a list.
       ->Upon clicking a demo, a popup will arise containing the name of the demo selected with an editable description and a textarea where the user should give the          feedback.User can give feedback to any demo present in demo list.It also has an option to like or dislike the demo.
       ->After giving feedback for desired demos, the submit button should be clicked upon doing which the user will be navigated back to the user register form         (FormUser). This form also has a back button which csn be used to navigate back to the starting page(StartPage form)
->If user selects the leaderboard option, he/she will be navigated to the leaderboard form where the demo list will be displayed in the descending order of votes.At the bottom the name of the demo with highest likes will be displayed.
        ->This form also has a back biutton which can be used to navigate to the start page(StartPage form).
->At the bottom of the starting form(StartPage form) there is a 'Add' button upon clicking which a popup will be displayed where the user can create demos.