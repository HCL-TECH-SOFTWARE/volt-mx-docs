CREATE TABLE `LoanObject`(
	`applicationId` BIGINT NOT NULL,
	`CreatedBy` VARCHAR(32),
	`CreatedDateTime` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
	`emailId` VARCHAR(40),
	`ID_doc_status` VARCHAR(40),
	`LastUpdatedBy` VARCHAR(32),
	`LastUpdatedDateTime` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
	`loanAmount` VARCHAR(40),
	`payslip_doc_status` VARCHAR(40),
	`phoneNo` BIGINT,
	`SoftDeleteFlag` BOOLEAN,
	`SSN` VARCHAR(40),
	`w2tax_doc_status` VARCHAR(40),
	PRIMARY KEY(`applicationId`)
);
ALTER TABLE `LoanObject`
	ADD CONSTRAINT `1f17f2813a80b9fb1eccb471023873` UNIQUE KEY(`applicationId`);
