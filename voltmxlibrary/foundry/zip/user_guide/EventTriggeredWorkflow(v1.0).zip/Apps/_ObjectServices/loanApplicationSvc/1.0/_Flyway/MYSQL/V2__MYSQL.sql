ALTER TABLE `LoanObject`
	MODIFY `loanAmount` BIGINT;
