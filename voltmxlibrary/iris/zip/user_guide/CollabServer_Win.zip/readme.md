config:
we can configure the server from "collabConfig.json" in collabConfig folder

keys in config:
 
    Server_Protocol : "http" or "https" (default http)
    port: port number (default 30000)

In the case of https, we need to have the below keys :

    server_key:  filename.key (this file has to be placed in collabConfig folder)
    server_cert: filename.cert (this file has to be placed in collabConfig folder)
	
	NOTE: only Valid CA certs can be used 

windows:
    run in windows just click the CollabServer.exe file 

MAC:
    run in mac 
    1.copy the collabConfig folder to USER HOME
    2.click the  file CollabServer
